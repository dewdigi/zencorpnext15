import React from 'react'
import Navbar from './Navbar'

const headerSection = () => {
  return (
    <div>
        <Navbar/>
    </div>
  )
}

export default headerSection