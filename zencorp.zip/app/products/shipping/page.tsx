import React from 'react'

const page = () => {
  return (
    <div>shipping</div>
  )
}

export default page